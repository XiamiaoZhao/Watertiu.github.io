# 行！整！旅行网页生成器

线上应用：https://xiamiaozhao.github.io/Watertiu.github.io/xingzheng/

游客免登录填写信息 → 程序生成手册 → 预览 / 分享 / 下载；管理员选择公开内容 → 发布到同一 GitHub 仓库的独立地址。

## 使用

1. 打开应用，填写旅行起止日期、人数、城市顺序和天数。
2. 可填酒店、已购交通、必去景点与预约时段、节奏等。
3. 点击“生成旅行网页”。红色冲突提示需先处理；预览中右上角可切换各子页。
4. “分享链接”默认隐藏具体预订；“下载旅行网页”保存完整私人版本，请自行选择收件人。离线文字/地图可看，照片、音频、导航仍需要网络。
5. 管理入口导入 JSON，预览公开版本。GitHub 管理员第一次需自行创建细粒度 token，只选择 `Watertiu.github.io`、Contents 读写。token 只在当前页面内存使用。
6. 发布路径固定为 `xingzheng/trips/<标识>/index.html`。保存后等待 GitHub Pages 部署完成。修改已发布行程时，填写同一标识、勾选“更新同一地址”。

**共享链接不是加密存储。** 链接中的片段包含经过筛选的行程，任何得到链接的人都能查看。浏览器草稿和备份 JSON 是私人完整数据。管理入口不会继承 Codex 的 GitHub 登录权限，因此需要一次性配置自己的发布令牌。

## 本地应用

需要 Node.js 22 或更新版本，无第三方依赖。

```sh
npm start
```

打开终端显示的 Local 地址。也可直接使用在线应用，无需本地环境。

```sh
npm test
npm run build
```

## 可选 AI 服务

普通生成、已有城市资料、日历、路线图、导出、分享和酒店微调均不调用 AI。

当前付费 AI 没有启用。已实现可选候选景点接口：配置服务端 `.env` 的 `AI_BASE_URL`、`AI_MODEL`、`AI_API_KEY` 和随机 `APP_ACCESS_CODE`，再运行 `node --env-file=.env server.mjs`。适配 Chat Completions JSON 响应接口，可使用国内可访问且兼容的服务商。模型请按账号实际可用列表填写。

服务器只发送未覆盖的城市名、兴趣和节奏，不发送酒店、票据、完整行程或图片。最多输出 1600 token；结果缓存 7 天；相同同时请求合并；默认每天 20 次模型调用、单 IP 每小时 10 次接口请求。缓存放 `.local/cache`，不上传 GitHub。缓存命中时显示本次 0 token；模型没有返回用量时明确显示未返回。

公开 AI 功能需要单独部署该 Node 服务到有 HTTPS 的服务器，配置 `ALLOWED_ORIGINS`，并在 `public/config.js` 设置 `apiBase`。GitHub Pages 仅托管静态页面，不能运行这个后台。访问码适合受控试用；面向大量用户应接账号体系、用户额度与费用监控。不要把 API key 写进 `config.js` 或仓库。

## 内容覆盖与未接服务

- 现有资料：徐州、苏州、上海、福州、泉州的路线与餐饮，复用原站 8 处精致地图语音导览；资料核查日 2026-10-25。
- 其他城市：可手填景点并生成日程与导航；有坐标才画地理图。有内容包后即可扩充，不必改网页模板。
- 天气：按需访问 Open-Meteo 的 16 天预报，标注来源和更新时间；支持已有五城，超期/失败留空，不编造温度。商业规模使用须按服务商条款另选套餐或服务，代码中的天气适配器可替换。
- 不包含：自动登录小红书/美团/鸭觅、实时车票余票、自动订票、已配置的订单截图 OCR、新景点讲稿/语音批量生成。界面不假装这些已完成。
- 自由文字偏好保存在草稿，不会暗中影响硬性约束；需要锁定的要求请使用结构化表单。
- 现有实景图片与语音引用你已公开站点的同源资源，保留原来源；新增素材应取得使用权。面向更大范围发行应优先开放许可图库并逐项清理未知授权素材。
- GitHub Pages 国内可访问性取决于网络，不能保证所有地区稳定；可将 `public/` 与生成网页同步到国内静态托管，替换域名配置即可。

## 扩展结构

- `public/core.js`：字段规范、日期/冲突校验、确定性规划、住宿增量更新、隐私筛选、压缩分享。
- `public/library.js`：版本化城市资料包。路线、点位、照片、票务、餐饮、绘画分离。
- `public/render.js`：手册页面和可交互地图；未知位置用列表而不是假地图。
- `public/links.js`：App 深链 + 预填关键词的网页备用。
- `public/services.js`：下载、天气、GitHub 写入。令牌不持久化。
- `public/app.js`：四步输入、私人草稿、生成/导出、AI 候选确认。
- `public/admin.js`：发布范围预览、身份核对、固定目录写入。
- `server.mjs`：可选 AI 后台、校验、缓存、限额与来源检查。
- `docs/需求与实现规格.md`：两个聊天的完整需求和程序/AI 划分。

城市包接口：每城 `name, checkedAt, routes[], foods[], art[]`。路线含 `id,title,nodes[],snacks[],drawing`；点位含 `id,name,lon,lat,intro,minutes,photo,ticket,guide`。照片含 `src,alt,author,source,license`；票务含 `price,reservation,url,wx,senior,source,checkedAt`。经纬度统一高德 GCJ-02 约位，天气独立用 WGS84 城市坐标。

## 参考文档

- GitHub Pages 是静态托管：https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- Contents 写入与 token 权限：https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents
- DeepSeek 兼容接口：https://api-docs.deepseek.com/api/create-chat-completion/
- 天气与期限：https://open-meteo.com/en/docs

不对未启用服务声称已完成线上验证。具体测试报告随交付记录保存。
